import numpy as np
from geneticalgorithm import geneticalgorithm as ga

def f(X):
    return np.sum(X)
    
def volume(X):
    surface = 80.0
    z = (surface-X[0]*X[1])/(2.0*(X[0]+X[1]))
    volume = X[0]*X[1]*z
    # use minimize problem set
    return -volume
    
varbound=np.array([[0,10]]*2)

model=ga(function=volume,dimension=2,variable_type='real',variable_boundaries=varbound)

model.run()
