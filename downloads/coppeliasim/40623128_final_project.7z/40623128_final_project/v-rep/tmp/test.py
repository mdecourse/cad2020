a = 10

if a == 10:
    if a==10:
        a =20
    if a==20:
        a = 4
print(a)

b = 10

if b == 10:
    if b==10:
        b =20
    elif b==20:
        b = 4
print(b)
